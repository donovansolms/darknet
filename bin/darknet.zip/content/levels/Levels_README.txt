You can create your own levels for the game, To do that follow this:

1. Just edit one of the level files, that is LevelOne--LevelThree.png and Sandbox.png
2. Everything you on the level png will be enabled for collisions
3. to make objects that do not collide with you, use the level_Objects.png file
4. Level and Object png must be of EXACT same dimensions
5. level and object files may NEVER exceed 6 megapixels in size!
6. Add spawnpoints in the .txt file for the level for bots, health and ammo. These must always be the same as in the level's 
   original txt file. See Templates/SpawnTemplate for a description of what can be what.
7. The spawn tct file must be in one line! spaces in variable values are allowed but NOWHERE else!!!


Enjoy!

Donovan Solms